<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('customers.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" id="name" placeholder="Nombre">
    <input type="text" name="age" id="age" placeholder="Edad">
    <input type="text" name="email" id="email" placeholder="Email">
    <input type="text" name="phone" id="phone" placeholder="Telefono">
    <input type="text" name="address" id="address" placeholder="Direccion">
    <input type="text" name="gender" id="gender" placeholder="genero">
    <input type="submit" value="Enviar">
<?php echo $__env->yieldSection(); ?><?php /**PATH /home/sandi/Desktop/III/parcial-json/resources/views/templates/form.blade.php ENDPATH**/ ?>